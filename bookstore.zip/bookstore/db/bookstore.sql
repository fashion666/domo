/*
Navicat MySQL Data Transfer

Source Server         : Java3
Source Server Version : 50562
Source Host           : localhost:3306
Source Database       : bookstore

Target Server Type    : MYSQL
Target Server Version : 50562
File Encoding         : 65001

Date: 2020-06-06 09:37:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(10) DEFAULT NULL,
  `details` varchar(255) DEFAULT NULL,
  `n_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`n_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('2', '公告2', '本周图书销售量再创新高', '2018-04-14 15:40:34');
INSERT INTO `notice` VALUES ('3', '公告3', '你好吗', '2018-04-14 15:42:13');
INSERT INTO `notice` VALUES ('4', '公告4', '儿童袜无无无无无无无无拖无无无无无', '2020-05-27 09:31:48');
INSERT INTO `notice` VALUES ('5', '公告信息1', '公告信息1公告信息1公告信息1', '2020-05-26 18:26:51');
INSERT INTO `notice` VALUES ('6', '公告信息2', '公告信息2公告信息2公告信息2', '2020-05-26 18:27:30');
INSERT INTO `notice` VALUES ('7', '公告信息3', '公告信息3公告信息3公告信息3', '2020-05-27 10:46:21');

-- ----------------------------
-- Table structure for orderitem
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `order_id` varchar(100) NOT NULL DEFAULT '',
  `product_id` varchar(100) NOT NULL DEFAULT '',
  `buynum` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderitem
-- ----------------------------
INSERT INTO `orderitem` VALUES ('0fdbf606-2f4d-4641-b50a-8c837d7c6bac', '2', '3');
INSERT INTO `orderitem` VALUES ('0fdbf606-2f4d-4641-b50a-8c837d7c6bac', '5', '1');
INSERT INTO `orderitem` VALUES ('1e7c8341-6272-4565-8252-dede9d4ea440', '1', '1');
INSERT INTO `orderitem` VALUES ('2659d047-0b9e-40fd-ad95-6b509ad4e431', '4', '1');
INSERT INTO `orderitem` VALUES ('3ab97692-329c-45ee-95cd-3d4564353314', '3', '1');
INSERT INTO `orderitem` VALUES ('3ab97692-329c-45ee-95cd-3d4564353314', '7', '2');
INSERT INTO `orderitem` VALUES ('440971ab-fceb-4f3d-af07-7968a5a9bf9c', '4', '1');
INSERT INTO `orderitem` VALUES ('c170c811-eb25-4876-b7f0-9861f4894b3e', '4', '1');
INSERT INTO `orderitem` VALUES ('d612d6c0-314a-404e-82bd-8bbb28d85429', '4', '1');
INSERT INTO `orderitem` VALUES ('d612d6c0-314a-404e-82bd-8bbb28d85429', '7', '2');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` varchar(100) NOT NULL,
  `money` double DEFAULT NULL,
  `receiverAddress` varchar(255) DEFAULT NULL,
  `receiverName` varchar(20) DEFAULT NULL,
  `receiverPhone` varchar(20) DEFAULT NULL,
  `paystate` int(11) DEFAULT '0',
  `ordertime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('0fdbf606-2f4d-4641-b50a-8c837d7c6bac', '121.5', '河南安阳', 'fff', '4658487', '0', '2020-06-06 08:20:49', '8');
INSERT INTO `orders` VALUES ('1e7c8341-6272-4565-8252-dede9d4ea440', '32', 'henan', 'lisi', '12454545', '0', '2020-05-01 11:31:20', '25');
INSERT INTO `orders` VALUES ('2659d047-0b9e-40fd-ad95-6b509ad4e431', '38', '河南南阳', '王五', '121445', '0', '2020-05-01 11:31:42', '25');
INSERT INTO `orders` VALUES ('3ab97692-329c-45ee-95cd-3d4564353314', '83.5', '河南南阳', 'aaa', '21544', '1', '2020-05-28 16:56:07', '8');
INSERT INTO `orders` VALUES ('440971ab-fceb-4f3d-af07-7968a5a9bf9c', '38', 'hdhj', 'ds', '1555', '1', '2020-05-01 10:49:32', '8');
INSERT INTO `orders` VALUES ('d612d6c0-314a-404e-82bd-8bbb28d85429', '94', '河南安阳', 'www', '154458755', '1', '2020-05-28 16:56:04', '8');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(40) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `category` varchar(40) DEFAULT NULL,
  `pnum` int(11) DEFAULT NULL,
  `imgurl` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES ('1', 'java web', '32', '计算机', '5', '/productImg/10/5/36ee63bc-c251-49ce-9b9a-b5e1e2e75ec0.jpg', '111111111111111111111111111111111111111111111113333');
INSERT INTO `products` VALUES ('2', '时空穿行', '34', '科技', '7', '/productImg/11/4/d79dc124-de69-4b77-847e-bc461bfdb857.jpg', '222222222222222222222222222222222222222222222222222222');
INSERT INTO `products` VALUES ('3', '大勇和小花的欧洲日记', '27.5', '少儿', '6', '/productImg/12/1/986b5e98-ee73-4717-89fd-b6ac26a8dc2c.jpg', '大勇和小花的欧洲日记大勇和小花的欧洲日记大勇和小花的欧洲日记大勇和小花的欧洲日记大勇和小花的欧洲日记大勇和小花的欧洲日记');
INSERT INTO `products` VALUES ('4', 'Java基础入门', '38', '计算机', '3', '/productImg/12/14/a1ace169-b53a-41c6-bdea-000e5946b2a5.png', 'Java基础入门Java基础入门Java基础入门Java基础入门Java基础入门Java基础入门');
INSERT INTO `products` VALUES ('5', '别做正常的傻瓜', '19.5', '励志', '2', '/productImg/14/1/792116e7-6d83-4be4-b3e5-4dd11b0b4565.jpg', '别做正常的傻瓜别做正常的傻瓜别做正常的傻瓜别做正常的傻瓜');
INSERT INTO `products` VALUES ('6', '中国国家地理', '23.8', '社科', '16', '/productImg/2/0/2105fbe5-400f-4193-a7db-d7ebac389550.jpg', '中国国家地理中国国家地理中国国家地理中国国家地理中国国家地理');
INSERT INTO `products` VALUES ('7', '学会宽容', '28', '励志', '8', '/productImg/6/5/a2da626c-c72d-4972-83de-cf48405c5563.jpg', '学会宽容学会宽容学会宽容');
INSERT INTO `products` VALUES ('bef3dccc-5d1a-45ea-a8c5-539970994bda', '数学', '32', '科技', '5', '/productImg/f8971f03-7f09-453d-8fb8-95651ace8b18-头像.jpg', 'sfsafdsdfsgr');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `PASSWORD` varchar(20) NOT NULL,
  `gender` varchar(2) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `introduce` varchar(100) DEFAULT NULL,
  `activeCode` varchar(50) DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `role` varchar(10) DEFAULT '普通用户',
  `registTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('8', 'abc', '123456', '女', '123@123.com', '12345678985', '', '38ea92ab-26c2-4725-aa73-b5e899e9767a', '1', '超级管理员', '2020-05-24 08:49:46');
INSERT INTO `user` VALUES ('16', 'aaa', '111111', '男', 'yuyafangh@163.com', '', '', '9039c221-fef5-4f2a-b1b1-5f6944252cca', '1', '普通用户', '2018-04-15 22:50:35');
INSERT INTO `user` VALUES ('17', 'cat5', '123456', '男', '28054153@qq.com', '15884556', '123456', null, '0', '普通用户', '2020-04-08 10:54:59');
INSERT INTO `user` VALUES ('25', 'shi', '123456', '男', 'fashion1314666@163.com', '15884556', '123456', '8c114c3c-f4d1-4e97-a5bf-92f0a9a66f5e', '1', '普通用户', '2020-04-08 16:15:15');
INSERT INTO `user` VALUES ('28', 'ddd', '123456', '男', '1245@qq.com', '15884556', 'dsafsr', null, '0', '普通用户', '2020-05-23 17:38:48');
INSERT INTO `user` VALUES ('30', 'sss', '123456', '男', '2264781278@qq.com', '1523722', 'sdfaf', null, '0', '普通用户', '2020-05-23 18:09:42');
INSERT INTO `user` VALUES ('34', 'wu', '123456789', '男', '1622028601@qq.com', '15445445', 'sfafse', '958903e4-0b5c-4147-add2-de29eef19f19', '0', '普通用户', '2020-05-23 18:52:40');
INSERT INTO `user` VALUES ('35', 'wei', '1234567', '男', '2466684934@qq.com', '1523722', 'dsgard', 'de082779-2315-45f1-abaf-ff59f77c28b6', '0', '普通用户', '2020-05-23 18:54:12');
