package com.bookstore.client.cart.handler;

import com.bookstore.client.products.service.IProductService;
import com.bookstore.commons.beans.Product;
import com.bookstore.commons.beans.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/client/cart")

public class CartHandler {

    @Autowired
    IProductService productService;

    @RequestMapping("/addCart")
    public String addCart(String id, HttpSession session){
        //商品的id为传入参数的商品加入购物车
        //购物车保存到session，购物车使用的数据类型使用map
        //map中商品为关键字，购买的数量为值
        //查询要放入购物车的商品信息
        Product product = productService.findProductById(id);
        //从session中获取购物车
        Map<Product,Integer> cart = (Map<Product, Integer>) session.getAttribute("cart");
        //如果session中的cart不存在，则新建购物车
        if (cart == null){
            //创建购物车
            cart = new HashMap<Product,Integer>();
        }
        //map.put方法是有返回值的；当key重复时，put返回值为原来value的值；
        //把商品加入购物车，数量为1
        //这里的count就是原来商品的数量
        Integer count = cart.put(product,1);
        //如果count为null说明购物车中没有商品，if不执行，购物车中商品的数量为1；
        //如果count不为null说明购物车里有原来的商品，在原来数量上加1；
        if (count != null){
            cart.put(product,count+1);
            //如果加1后大于商品库存，那么将商品数量设置为商品库存
            if ((count+1) > product.getPnum()){
                cart.put(product,count);
            }
        }
        session.setAttribute("cart",cart);
        return "redirect:/client/cart.jsp";
    }

    //改变商品数量
    @RequestMapping("/changeCart")
    public String changeCart(String id, Integer count, HttpSession session){
        //获取要改变数量的商品信息
        Product product = productService.findProductById(id);
        //从session中获取购物车中原始商品信息
        Map<Product,Integer> cart = (Map<Product, Integer>) session.getAttribute("cart");
        //如果改变后商品的数量为0，则从购物车删除该商品信息
        if (count == 0){
            cart.remove(product);
        }else {
            cart.put(product,count);
        }
        return "redirect:/client/cart.jsp";
    }

    //检验用户是否登录
    /*@RequestMapping("/findLogin_user")
    public String findLogin_user(HttpSession session, Model model){
        User Login_user = (User) session.getAttribute("Login_user");
        if (Login_user == null){
            model.addAttribute("login_error","用户未登录，请登录后下订单");
            return "/client/login.jsp";
        }else {
            return "/client/order.jsp";
        }
    }*/

}
