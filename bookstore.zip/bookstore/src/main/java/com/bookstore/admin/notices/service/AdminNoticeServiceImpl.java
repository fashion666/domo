package com.bookstore.admin.notices.service;

import com.bookstore.admin.notices.dao.IAdminNoticeDao;
import com.bookstore.commons.beans.Notice;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class AdminNoticeServiceImpl implements IAdminNoticeService {

    @Resource
    IAdminNoticeDao adminNoticeDao;

    @Override
    public List<Notice> findNotices() {
        return adminNoticeDao.selectNotices();
    }

    @Override
    public void addNotice(Notice notice) {
        adminNoticeDao.insertNotice(notice);
    }

    @Override
    public Notice findNoticeById(Integer id) {
        return adminNoticeDao.selectNoticeById(id);
    }

    @Override
    public void editNotice(Notice notice) {
        adminNoticeDao.updateNotice(notice);
    }

    @Override
    public void removeNotice(Integer id) {
        adminNoticeDao.deleteNotice(id);
    }
}
