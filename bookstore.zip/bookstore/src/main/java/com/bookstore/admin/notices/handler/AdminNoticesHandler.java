package com.bookstore.admin.notices.handler;

import com.bookstore.admin.notices.service.IAdminNoticeService;
import com.bookstore.commons.beans.Notice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/admin/notices")
public class AdminNoticesHandler {

    @Autowired
    IAdminNoticeService adminNoticeService;

    //查询所有公告信息
    @RequestMapping("/findNotices")
    public String findNotices(Model model){
        List<Notice> notices = adminNoticeService.findNotices();
        model.addAttribute("notices",notices);
        return "/admin/notices/list.jsp";
    }

    //添加公告信息
    @RequestMapping("/addNotice")
    public String addNotice(Notice notice){
        adminNoticeService.addNotice(notice);
        return "/admin/notices/findNotices";
    }

    //查询所要修改的公告信息
    @RequestMapping("/findNoticeById")
    public String findNoticeById(Integer id,Model model){
        Notice notice = adminNoticeService.findNoticeById(id);
        System.out.println(notice);
        model.addAttribute("n",notice);
        return "/admin/notices/edit.jsp";
    }

    //修改公告信息
    @RequestMapping("/editNotice")
    public String editNotice(Notice notice){
        adminNoticeService.editNotice(notice);
        return "/admin/notices/findNotices";
    }

    //删除公告信息
    @RequestMapping("/removeNotice")
    public String removeNotice(Integer id){
        adminNoticeService.removeNotice(id);
        return "/admin/notices/findNotices";
    }
}
