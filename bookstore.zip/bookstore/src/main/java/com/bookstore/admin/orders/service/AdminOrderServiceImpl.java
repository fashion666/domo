package com.bookstore.admin.orders.service;

import com.bookstore.admin.orders.dao.IAdminOrderDao;
import com.bookstore.commons.beans.Order;
import com.bookstore.commons.beans.OrderItem;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class AdminOrderServiceImpl implements IAdminOrderService{

    @Resource
    IAdminOrderDao adminOrderDao;

    @Override
    public List<Order> findOrders() {
        return adminOrderDao.selectOrders();
    }

    @Override
    public List<Order> findOrderByManyCondition(Order order) {
        return adminOrderDao.selectOrderByManyCondition(order);
    }

    @Override
    public List<OrderItem> findOrderById(String id) {
        return adminOrderDao.selectOrdersById(id);
    }

    @Override
    public void removeOrderById(String id) {
        //删除订单和订单项
        adminOrderDao.deleteOrderById(id);
        adminOrderDao.deleteOrderItemById(id);
    }
}
