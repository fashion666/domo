package com.bookstore.utils;

import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.spi.http.HttpExchange;
import java.io.FileWriter;
import java.io.IOException;

public class AlipayConfig {

    // 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
    public static String app_id = "2016102400748831";

    // 商户私钥，您的PKCS8格式RSA2私钥
    public static String merchant_private_key = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCAEHECT03iIXzAl36YW8JueE8Rww2Ro8C2uANYolzYvBHA0KfBOX3D7ngZhyozB+JvaEusbCGOpdu+CCeEbADWOMrfYPFRchjifNyw9udB5cxDcWeLBiX1QHEeOQpJBcraRc254nXa6hJ1RrH2b3WHb/9lmzg7MxrgoS4Stpznc0nJD0+vfqv23MzRPIk+ongbOR/ujXaU/ayfOuPH8PZAt7svIjT72dmRMfxo0NdScYU1XacnEl0f6hs/hR5s9iYcm5PfmV/ZODlfYGDN9F4PCJRIyHls4wK2IajITXWibZbjn92+9qNSjX1jvAOzJbOesjq3tx7jZallb9jwTn6HAgMBAAECggEAElRIGHCJUShB1r7YG65mcbE+f+hO9N1fI8fKktEKQOsKD3LNz9YOrhBfmCfEXnFuc0uWKSOA2g3bGaPJJCbhJ8gRIU+aunF+JkyAucNc7g2Z4r1EeJ10qVmD1zOKyVDO69a5zzUecSq3YZmwtvjU9YGOKFjC/5Yc7rGjCoKgim+9sJerQy7Myxf6Tu3qYxVikVXgAO1gI6elLnFWtK4KF/xTb1ZBumFpv0jSTEAa7p1ecP4KL39LUAiFdUdE4kEa+7xYPsZxd0Se+BhxIerJUHXvs+48h0IDsYeb9yywCCZOO8fk8uqTF//NAMWDz6d22CpV7WpmhDtPG2nDSxQogQKBgQDIuami67UFlE0/E88e5HZGBWlF0R2Hms2xMNMbGeSEc0NnDWEw11goFbRhqYSXygSknaxnWG/KHPgYbbjJtCT66WGERY227/pgXy2rZ6VejmTmYxAc1rcaktJKGHxSFUIoiD+ycR3XPZdm7i28YSMcHKZ1sNGTtLRA0fw037swtwKBgQCjVHa1h5RgWzm1gdC5CRETqYE21OlorAdZQld8iM1E/PxeSzEaZURWTsVI82ouwYMebTZ1ChdqvygCOX0EAUAoxoNsM1qU/ui+j/0uuwaH+81Em6ap8j2C84NnBEulxDxldRTSsRgPXlpG6hQ2XgnWgh941YsncJS3Glw0eLywsQKBgQCrAQmVRAvnYe3hVCX7YpWkl82U7k+jDG46i6b+CrQVZwFAVTS84Gk5VSxkm3/btP75o16SeNRcMwvl++wW4wMyRAuRHZRbCt2aptuIkHdhNByf7jt25jH+UKEZAP1BDN1dHJ5vjlDm45EN3tJWD8dSltH1qBsUJDoAkySzgvu9xwKBgQCe0lNc0ioGSK8lQMamJ5rjc8CigQc3MZEzyr8n6h8xJpCBYLyu3ipFgvN0rL5kGOhXffumc9mxg5B0GVLnwg+RlvfVD1rV58qLA5k/B76iHMjOHk1ClLwbyo/MbPDikJ/qSJ+nAW5UA3vl2VkuRONsI7xW09As2dzC8G8Y1w8lAQKBgHtCnsN+HJ87rnTJ1/IT0LkbDDdWOeAhb1ro/HDc3v/D16g2/srU5fvKDomEQz18RR/0em7JyLpGLa6CWjRl9vY1K9ilcTtksfIHa5LrN07dBloCHYJJHEK5HZglZqpfVEssH7+h+2k1BDJzbK/zIVU6DcvANjdsumaHnkxlemSW";

    // 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlyXN2KNzZU6iGdd63RwHvFpMJCrOkxxNbBRH08Qt8WtvKeb1gqiITRMl3O7sHwQhen/8XQu8lzfqebrvyricMRtPzMxc9sw57HVxdaF5r5QegVjlGrj6wbGNUJ/n5YU38bE/+VC/LUdliCenI47641aN7zjBFVurnof6MVhz/0TyWbmmSGAgydZmkzGkU9xTuqZfUqLI+ORLtWVB/sF/VQeav90MZAffhXKqJXuE73BfQGdoXNYiklJY6joGWzKTtU8jBiLKdDVkSKBU0fKP2jXnuNHt6wbtxpcqO/JZt7YsSsfs36gMiwHTmQ6PhkGGG6eH59Xodf19/5P9gNFrOwIDAQAB";

    // 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    public static String notify_url = "http://工程公网访问地址/alipay.trade.page.pay-JAVA-UTF-8/notify_url.jsp";

    // 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    public static String return_url = "http://localhost:8080/bookstore_war/client/order/paysuccess";

    // 签名方式
    public static String sign_type = "RSA2";

    // 字符编码格式
    public static String charset = "utf-8";

    //沙箱支付宝网关
    public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";

    // 真实支付宝网关
    //public static String gatewayUrl = "https://openapi.alipay.com/gateway.do";

    // 支付宝网关
    public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /**
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
